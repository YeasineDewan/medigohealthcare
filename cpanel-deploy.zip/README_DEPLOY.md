# Medigo cPanel Deployment

1. Open cPanel File Manager and go to `public_html`.
2. Enable "Show Hidden Files".
3. Remove old files from `public_html`.
4. Upload all files from this `dist/` folder (including `.htaccess`).
5. Clear browser cache and open your domain.

Do not upload project source files like `src/` or root `index.html`.
